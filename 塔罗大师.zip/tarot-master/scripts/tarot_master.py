"""
title: 塔罗大师随机抽牌
description: 从完整 78 张塔罗牌中进行单次无重复随机抽牌，支持正逆位与仅正位模式。
required_open_webui_version: 0.5.0
version: 1.0.0
licence: MIT
"""

import argparse
import json
import random
import sys

_MAJOR_ARCANA = (
    ("major_00", "愚人", "The Fool"),
    ("major_01", "魔术师", "The Magician"),
    ("major_02", "女祭司", "The High Priestess"),
    ("major_03", "女皇", "The Empress"),
    ("major_04", "皇帝", "The Emperor"),
    ("major_05", "教皇", "The Hierophant"),
    ("major_06", "恋人", "The Lovers"),
    ("major_07", "战车", "The Chariot"),
    ("major_08", "力量", "Strength"),
    ("major_09", "隐士", "The Hermit"),
    ("major_10", "命运之轮", "Wheel of Fortune"),
    ("major_11", "正义", "Justice"),
    ("major_12", "倒吊人", "The Hanged Man"),
    ("major_13", "死神", "Death"),
    ("major_14", "节制", "Temperance"),
    ("major_15", "恶魔", "The Devil"),
    ("major_16", "高塔", "The Tower"),
    ("major_17", "星星", "The Star"),
    ("major_18", "月亮", "The Moon"),
    ("major_19", "太阳", "The Sun"),
    ("major_20", "审判", "Judgement"),
    ("major_21", "世界", "The World"),
)

_SUITS = (
    ("wands", "权杖", "Wands"),
    ("cups", "圣杯", "Cups"),
    ("swords", "宝剑", "Swords"),
    ("pentacles", "星币", "Pentacles"),
)

_RANKS = (
    (1, "王牌", "Ace"),
    (2, "二", "Two"),
    (3, "三", "Three"),
    (4, "四", "Four"),
    (5, "五", "Five"),
    (6, "六", "Six"),
    (7, "七", "Seven"),
    (8, "八", "Eight"),
    (9, "九", "Nine"),
    (10, "十", "Ten"),
    (11, "侍从", "Page"),
    (12, "骑士", "Knight"),
    (13, "王后", "Queen"),
    (14, "国王", "King"),
)


def _build_deck():
    cards = [
        {"id": card_id, "name_zh": name_zh, "name_en": name_en, "arcana": "major", "suit": None}
        for card_id, name_zh, name_en in _MAJOR_ARCANA
    ]
    for suit_id, suit_zh, suit_en in _SUITS:
        for value, rank_zh, rank_en in _RANKS:
            cards.append(
                {
                    "id": f"{suit_id}_{value:02d}",
                    "name_zh": f"{suit_zh}{rank_zh}",
                    "name_en": f"{rank_en} of {suit_en}",
                    "arcana": "minor",
                    "suit": suit_id,
                }
            )
    return tuple(cards)


_DECK = _build_deck()
_RNG = random.SystemRandom()


def _draw_result(count, upright_only):
    if isinstance(count, bool) or not isinstance(count, int):
        raise ValueError("count 必须是整数")
    if not 1 <= count <= len(_DECK):
        raise ValueError(f"count 必须在 1 到 {len(_DECK)} 之间")
    if not isinstance(upright_only, bool):
        raise ValueError("upright_only 必须是布尔值")

    cards = []
    for card in _RNG.sample(_DECK, count):
        orientation = "upright" if upright_only else _RNG.choice(("upright", "reversed"))
        cards.append(
            {
                **card,
                "orientation": orientation,
                "orientation_zh": "正位" if orientation == "upright" else "逆位",
            }
        )
    return {
        "ok": True,
        "count": count,
        "reversals_enabled": not upright_only,
        "cards": cards,
    }


class Tools:
    async def draw_tarot(self, count: int = 3, upright_only: bool = False) -> dict:
        """
        从完整 78 张塔罗牌中随机抽牌，单次调用不会重复。只返回客观抽牌结果，不解牌。

        :param count: 本次抽取的牌数，由解读需求决定，范围为 1 到 78。
        :param upright_only: 是否仅使用正位；默认为 False，即每张牌随机正位或逆位。
        :return: 包含抽牌状态、牌数及有序牌面列表的字典。
        """
        try:
            return _draw_result(count, upright_only)
        except ValueError as exc:
            return {"ok": False, "error": str(exc), "cards": []}


def _main():
    parser = argparse.ArgumentParser(description="塔罗大师：单次无重复随机抽牌")
    parser.add_argument("--count", type=int, default=3, help="抽牌数量，范围为 1 到 78")
    parser.add_argument("--upright-only", action="store_true", help="仅抽取正位")
    args = parser.parse_args()
    try:
        result = _draw_result(args.count, args.upright_only)
    except ValueError as exc:
        parser.error(str(exc))
    if hasattr(sys.stdout, "reconfigure"):
        sys.stdout.reconfigure(encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(_main())
